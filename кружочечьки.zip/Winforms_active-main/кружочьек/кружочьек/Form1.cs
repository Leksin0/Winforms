﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace кружочьек
{

    public partial class Form1 : Form
    {
        static readonly string[] sizeArray = { "Большой", "Средний", "Маленький" };
        static readonly string[] shapeArray = { "Прямоугольник", "Квадрат", "Эллипс", "Круг", "Треугольник" };
        static readonly string[] colorArray = { "Зелёный", "Синий", "Оранжевый", "Фиолетовый", "Красный" };
        Color figureColor;

        public Form1()
        {
            InitializeComponent();
            cmbxSize.DataSource = sizeArray;
            cmbxShape.DataSource = shapeArray;
            cmbxColor.DataSource = colorArray;
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            if (cmbxColor.Text == colorArray[0])
                figureColor = Color.Green;
            else if (cmbxColor.Text == colorArray[1])
                figureColor = Color.Blue;
            else if (cmbxColor.Text == colorArray[2])
                figureColor = Color.Orange;
            else if (cmbxColor.Text == colorArray[3])
                figureColor = Color.Magenta;
            else if (cmbxColor.Text == colorArray[4])
                figureColor = Color.Red;
            else
                MessageBox.Show("Выберите цвет из предложенных");

            panCanvas.Refresh();
        }

        private void panCanvas_Paint(object sender, PaintEventArgs e)
        {
            Point cntr = new Point(panCanvas.Width / 2, panCanvas.Height / 2);
            Point PT = new Point(0, 0);
            Size SZ = new Size(0, 0);
            Graphics drawer = e.Graphics;
            if (cmbxSize.Text == sizeArray[0])
            { 
                PT = new Point(panCanvas.Width / 8, panCanvas.Height / 8);
                SZ = new Size(panCanvas.Width / 4 * 3, panCanvas.Height /4 * 3);
            }
            else if (cmbxSize.Text == sizeArray[1])
            {
                PT = new Point(panCanvas.Width / 4, panCanvas.Height / 4);
                SZ = new Size(panCanvas.Width / 2, panCanvas.Height / 2);
            }
            else if (cmbxSize.Text == sizeArray[2])
            {
                PT = new Point(panCanvas.Width / 3, panCanvas.Height / 3);
                SZ = new Size(panCanvas.Width / 3, panCanvas.Height / 3);
            }
            else
            {
               MessageBox.Show("Выберите размер из предложенных");
            }
            int prfSZ = panCanvas.Width > panCanvas.Height ? SZ.Height : SZ.Width;
            Point prfPT = new Point((panCanvas.Width - prfSZ) / 2, (panCanvas.Height - prfSZ) / 2);

            switch (cmbxShape.Text)
            {
                case "Прямоугольник":
                    drawer.FillRectangle(new SolidBrush(figureColor), PT.X, PT.Y, SZ.Width, SZ.Height);
                    break;
                case "Квадрат":
                    drawer.FillRectangle(new SolidBrush(figureColor), prfPT.X, prfPT.Y, prfSZ, prfSZ);
                    break;
                case "Эллипс":
                    drawer.FillEllipse(new SolidBrush(figureColor), PT.X, PT.Y, SZ.Width, SZ.Height);
                    break;
                case "Круг":
                    drawer.FillEllipse(new SolidBrush(figureColor), prfPT.X, prfPT.Y, prfSZ, prfSZ);
                    break;
                case "Треугольник":
                    Point aPT = new Point(cntr.X, cntr.Y - SZ.Height / 2);
                    Point bPT = new Point(cntr.X - SZ.Width / 2, cntr.Y + SZ.Height / 2);
                    Point cPT = new Point(cntr.X + SZ.Width / 2, cntr.Y + SZ.Height / 2);
                    drawer.FillPolygon(new SolidBrush(figureColor), new Point[] { aPT, bPT, cPT });
                    break;
                default:
                    MessageBox.Show("Выберите форму из предложенных");
                    break;
            }
        }
    }
}